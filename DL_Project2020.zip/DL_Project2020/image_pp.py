import numpy as np 
import os
import matplotlib.pyplot as plt 
import matplotlib.image as mpimg
import cv2

# shuffeling all the cell image list and their labels randomly to prevent bias
def reorder(old_list, order):
    new_list = []
    for i in order:
        new_list.append(old_list[i])
    return new_list

#Defining Image Data Files
infected = "test_set/infected"
uninfected = "test_set/uninfected"

infected_Paths = []
uninfected_Paths = []

# Assigning empty array to training cell images and labels
cell_images = []
cell_labels = []

# setting image height and width to 150 for better results
height = 150
width = 150

# getting all file paths from infected image path
for file in os.listdir(infected):
	if file.endswith('.png'):
		file_path = os.path.join(infected, file)
		infected_Paths.append(file_path)

for file in os.listdir(uninfected):
	if file.endswith('.png'):
		file_path = os.path.join(uninfected, file)
		uninfected_Paths.append(file_path)

# from images in file paths read, resize and remove all the noise
for file_path in infected_Paths:
    # getting the image which will be converted to numpy array afterwards
	img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED)
    # changing the image size to 150 x 150 and convert the numpy array values to float 32						
	resized_IMAGE = cv2.resize(img, (height, width)).astype('float32')
    # pixel scaling down of the  values from [0-255] to [0-1]		
	resized_IMAGE = resized_IMAGE / 255		
    # Apply Gaussian Blurring to Image									
	blur_img = cv2.GaussianBlur(resized_IMAGE, (1, 1), 0)
    # Append resized images to the cell images list					
	cell_images.append(blur_img)
    # Adding label for infected images - 1											
	cell_labels.append(1)													


for file_path in uninfected_Paths:
	img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED)						
	resized_IMAGE = cv2.resize(img, (height, width)).astype('float32')		
	resized_IMAGE = resized_IMAGE / 255	
	blur_img = cv2.GaussianBlur(resized_IMAGE, (1, 1), 0)					
	cell_images.append(blur_img)											

#Sample uninfected image
sample_uninfected = cell_images[-1]										

# Shuffling Training Data randomly
#Set Random Seed
np.random.seed(seed=97)			
#Array of indices corresponding to length of cell images											
indexes = np.arange(len(cell_labels))
# shulffing randomly all the indexes										
np.random.shuffle(indexes)
# listing all the indexes													
indexes = indexes.tolist()													

# Reordering cell labels and images
cell_labels = reorder(cell_labels, indexes)									
cell_images = reorder(cell_images, indexes)									

# Converting cell images and labels to numpy array
image_Array = np.array(cell_images)											
label_Array = np.array(cell_labels)											

# Saving numpy array which will be used to build cnn model. 
np.save('Img_Array.npy', image_Array)
np.save('Lbl_Array.npy', label_Array)

