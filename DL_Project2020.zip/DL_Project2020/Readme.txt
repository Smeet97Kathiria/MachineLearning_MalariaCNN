#!/usr/bin/python

# To run the project just run the cnn2 python file.

# The dataset used for the project was big so I was not able to upload it. 
# Step 2 -If you would like to use the same dataset, you can download it from the below link and put it in your project folder

 Dataset - https://drive.google.com/open?id=14G9uzCvdvC_N9_QcaMVmcOLbqEuVKxRP
# After doing step 2, you can run the cnn2 file again. 


# Make sure you have all the required libraries installed first. 